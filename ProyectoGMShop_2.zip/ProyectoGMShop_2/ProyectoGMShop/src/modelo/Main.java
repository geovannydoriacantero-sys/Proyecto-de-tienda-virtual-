package modelo;

import controladorvista.LoginControlador;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import tienda.ListaProducto;
import tienda.ListaUsuario;
import tienda.ProductoAdministrador;
import tienda.UsuarioAdministrador;

public class Main extends Application {

    private static ListaUsuario listaUsuarios = new ListaUsuario();
    private static ListaProducto catalogo = new ListaProducto();
    private static ProductoAdministrador productoAdministrador = new ProductoAdministrador();
    private static UsuarioAdministrador usuarioAdministrador = new UsuarioAdministrador();

    private static Stage mainStage;
    private static Image logo;

    @Override
    public void start(Stage stage) throws Exception {
        mainStage = stage;
        logo = new Image(getClass().getResourceAsStream("/images/logo.png"));

        catalogo = productoAdministrador.cargarProductos();
        listaUsuarios = usuarioAdministrador.cargarUsuarios(productoAdministrador);

        FXMLLoader loader = abrirVentana("/vista/Login.fxml");

        LoginControlador controller = loader.getController();
        controller.setListaUsuarios(listaUsuarios);
        controller.setProductoAdmin(productoAdministrador);
        controller.setUsuarioAdmin(usuarioAdministrador);
    }

    public static void main(String args[]) {
        launch();
    }

    public static FXMLLoader abrirVentana(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxml));

        Parent root = loader.load();
        mainStage.setTitle("ShopGM");
        mainStage.getIcons().add(logo);
        mainStage.setScene(new Scene(root));
        mainStage.show();
        
        return loader;
    }

}

package tienda;

public class ListaProducto {

    private NodoProducto cabeza;

    public ListaProducto() {
        cabeza = null;
    }

    public void agregarProducto(Producto producto) {
        NodoProducto nuevo = new NodoProducto(producto);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoProducto auxiliar = cabeza;
            while (auxiliar.siguiente != null) {
                auxiliar = auxiliar.siguiente;
            }
            auxiliar.siguiente = nuevo;
        }
    }

    public void limpiar() {
        NodoProducto actual = cabeza;
        while (actual != null) {
            NodoProducto siguiente = actual.siguiente;
            actual.siguiente = null; // romper enlace
            actual = siguiente;
        }
        cabeza = null;
    }

    public NodoProducto getCabeza() {
        return cabeza;
    }

    public boolean existeProducto(String id) {
        NodoProducto aux = cabeza;
        while (aux != null) {
            if (aux.producto.getId().equalsIgnoreCase(id)) {
                return true;
            }
            aux = aux.siguiente;
        }
        return false;
    }

    public Producto buscarProducto(String id) {
        NodoProducto aux = cabeza;
        while (aux != null) {
            if (aux.producto.getId().equalsIgnoreCase(id)) {
                return aux.producto;
            }
            aux = aux.siguiente;
        }
        return null;
    }
}

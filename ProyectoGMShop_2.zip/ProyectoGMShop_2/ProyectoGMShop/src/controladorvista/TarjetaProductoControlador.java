package controladorvista;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Rectangle;
import tienda.ListaUsuario;
import tienda.Producto;
import tienda.Usuario;
import tienda.UsuarioAdministrador;

public class TarjetaProductoControlador implements Initializable {

    private Usuario usuario;
    private ListaUsuario listaUsuarios;
    private UsuarioAdministrador usuarioAdmin;
    private Producto producto;

    @FXML
    private ImageView imgProducto;
    @FXML
    private Label lblNombre;
    @FXML
    private Label lblPrecio;
    
    @FXML
    private HBox botonesTarjeta;
    
    public void ocultarBotonesTarjeta() {
        botonesTarjeta.setVisible(false);
    }

    public void setUsuarioAdmin(UsuarioAdministrador usuarioAdmin) {
        this.usuarioAdmin = usuarioAdmin;
    }

    public void setListaUsuarios(ListaUsuario listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public void setUsuario(Usuario u) {
        this.usuario = u;
    }

    public void setProducto(Producto p) {
        this.producto = p;
        
        lblNombre.setText(p.getNombre());
        lblPrecio.setText("$ " + p.getPrecio());

        Image image = new Image("file:" + p.getRutaImagen());
        imgProducto.setImage(image);
    }

    @FXML
    private void agregarADeseados(ActionEvent event) {
        if (usuario.agregarADeseados(producto)) {

            usuarioAdmin.guardarUsuarios(listaUsuarios);

            System.out.println("Producto agregado y guardado");
        } else {
            System.out.println("Este producto ya está en deseados");
        }

    }
    @FXML
    private void agregarACarrito(ActionEvent event) {
        if (usuario.agregarACarrito(producto)) {

            usuarioAdmin.guardarUsuarios(listaUsuarios);

            System.out.println("Producto agregado y guardado");
        } else {
            System.out.println("Este producto ya está en deseados");
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        redondearImagenes();
    }

    public void redondearImagenes() {
        Rectangle clip = new Rectangle(116, 120);
        clip.setArcWidth(64);
        clip.setArcHeight(64);
        imgProducto.setClip(clip);
    }
}

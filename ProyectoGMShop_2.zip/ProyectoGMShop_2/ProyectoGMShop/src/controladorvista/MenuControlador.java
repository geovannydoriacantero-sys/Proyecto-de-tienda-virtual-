package controladorvista;

import java.io.IOException;
import javafx.scene.shape.Rectangle;
import javafx.event.ActionEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ParallelTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import modelo.Main;
import tienda.ListaProducto;
import tienda.ListaUsuario;
import tienda.NodoProducto;
import tienda.Producto;
import tienda.ProductoAdministrador;
import tienda.Usuario;
import tienda.UsuarioAdministrador;

public class MenuControlador implements Initializable {

    ProductoAdministrador productoAdmin;
    UsuarioAdministrador usuarioAdmin;
    private Map<String, Label> mapaCategorias;
    private Usuario usuario;
    private ListaUsuario listaUsuario;

    private List<TarjetaCarritoControlador> tarjetas = new ArrayList<>();

    private final double costoEnvio = 10000;

    public MenuControlador() {
        mapaCategorias = new HashMap<>();
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        cargarUsuario();
        try {
            mostrarProductosPorCategoria();
            mostrarProductosCarrito();
        } catch (IOException ex) {
            Logger.getLogger(MenuControlador.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setListaUsuarios(ListaUsuario listaUsuarios) {
        this.listaUsuario = listaUsuarios;
    }

    public void setProductoAdmin(ProductoAdministrador producto_admin) {
        this.productoAdmin = producto_admin;
    }

    public void setUsuarioAdmin(UsuarioAdministrador user_admin) {
        this.usuarioAdmin = user_admin;
    }

    private boolean menuAbierto = false;

    @FXML
    private AnchorPane anchorPane;
    @FXML
    private Pane panelCatalogo;
    @FXML
    private Pane panelDeseados;
    @FXML
    private Pane panelCarrito;
    @FXML
    private Pane panelHistorial;

    @FXML
    private Button botonHome;
    @FXML
    private Button botonDeseados;
    @FXML
    private Button botonHistorial;
    @FXML
    private Button botonCarrito;
    @FXML
    private Button botonPagar;

    @FXML
    private VBox menuDesplegable;
    @FXML
    private Button boton1_mlateral;
    @FXML
    private Button boton2_mlateral;
    @FXML
    private Button boton3_mlateral;
    @FXML
    private Button botonMenu;
    @FXML
    private Button botonMenu2;
    @FXML
    private Rectangle fondoOscuro;

    @FXML
    private Button botonHombre;
    @FXML
    private Button botonMujer;
    @FXML
    private Button botonAccesorios;

    @FXML
    private Label sinDeseados;
    @FXML
    private Label sinCarrito;
    @FXML
    private Label sinHistorial;

    @FXML
    private Label labelSubTotal;
    @FXML
    private Label labelEnvio;
    @FXML
    private Label labelTotal;

    @FXML
    private Label labelUsuario;
    @FXML
    private ScrollPane scrollCatalogo;
    @FXML
    private ScrollPane scrollDeseados;
    @FXML
    private ScrollPane scrollHistorial;
    @FXML
    private ScrollPane scrollCarrito;
    @FXML
    private VBox contenedorCatalogo;
    @FXML
    private VBox contenedorDeseados;
    @FXML
    private VBox contenedorCarrito;
    @FXML
    private VBox contenedorHistorial;

    @FXML
    private TextField fieldBuscar;

    @FXML
    public void cerrarSesion(ActionEvent event) throws IOException {
        Stage stage = (Stage) boton1_mlateral.getScene().getWindow();
        stage.close();

        FXMLLoader loader = Main.abrirVentana("/vista/Login.fxml");
        LoginControlador login_c = loader.getController();
        login_c.setListaUsuarios(listaUsuario);
        login_c.setProductoAdmin(productoAdmin);
        login_c.setUsuarioAdmin(usuarioAdmin);
    }

    @FXML  
    public void abrirAdministrador(ActionEvent event) {
        System.out.println("Holiiss!");
    }
    @FXML
    public void mostrarHome(ActionEvent event) {
        panelDeseados.setVisible(false);
        panelHistorial.setVisible(false);
        panelCarrito.setVisible(false);
        panelCatalogo.setVisible(true);
    }

    @FXML
    public void mostrarDeseados(ActionEvent event) {
        panelHistorial.setVisible(false);
        panelCatalogo.setVisible(false);
        panelCarrito.setVisible(false);
        panelDeseados.setVisible(true);
        mostrarProductosDeseados();
    }

    @FXML
    public void mostrarHistorial(ActionEvent event) {
        panelCatalogo.setVisible(false);
        panelDeseados.setVisible(false);
        panelCarrito.setVisible(false);
        panelHistorial.setVisible(true);
        mostrarProductosHistorial();
    }

    @FXML
    public void mostrarCarrito(ActionEvent event) {
        panelCatalogo.setVisible(false);
        panelDeseados.setVisible(false);
        panelHistorial.setVisible(false);

        mostrarProductosCarrito();
        actualizarTotal();
        panelCarrito.setVisible(true);
    }

    @FXML
    public void pagarProductos(ActionEvent event) {

        for (TarjetaCarritoControlador t : tarjetas) {
            if (usuario.agregarAHistorial(t.getProducto())) {
                System.out.println("Producto agregado y guardado al Historial: " + t.getProducto().getNombre());
            }
        }
        usuario.getListaCarrito().limpiar();
        tarjetas.clear();
        usuarioAdmin.guardarUsuarios(listaUsuario);
        mostrarProductosCarrito();
        actualizarTotal();
    }

    @FXML
    public void seleccionarCategoriaHombre(ActionEvent event) {
        Label destino = mapaCategorias.get("hombre");
        scrollToNode(scrollCatalogo, destino);
        aplicarSeleccion(botonHombre);
    }

    @FXML
    public void seleccionarCategoriaMujer(ActionEvent event) {
        Label destino = mapaCategorias.get("mujer");
        scrollToNode(scrollCatalogo, destino);
        aplicarSeleccion(botonMujer);
    }

    @FXML
    public void seleccionarCategoriaAccesorios(ActionEvent event) {
        Label destino = mapaCategorias.get("accesorios");
        scrollToNode(scrollCatalogo, destino);
        aplicarSeleccion(botonAccesorios);
    }

    public void scrollToNode(ScrollPane scrollPane, Node node) {
        if (node == null || scrollPane.getContent() == null) {
            return;
        }

        // Posición del nodo relativa al contenido
        double contentHeight = scrollPane.getContent().getBoundsInLocal().getHeight();
        double viewportHeight = scrollPane.getViewportBounds().getHeight();
        double nodeY = node.getBoundsInParent().getMinY();

        // Normalizar posición al rango [0,1]
        double vValue = nodeY / (contentHeight - viewportHeight);
        vValue = Math.min(Math.max(vValue, 0), 1); // Limitar entre 0 y 1

        // Animar suavemente el scroll
        Timeline timeline = new Timeline();
        KeyValue kv = new KeyValue(scrollPane.vvalueProperty(), vValue);
        KeyFrame kf = new KeyFrame(Duration.millis(300), kv); // 300ms de duración
        timeline.getKeyFrames().add(kf);
        timeline.play();
    }

    private void aplicarSeleccion(Button botonSeleccionado) {

        Button[] botones = {botonHombre, botonMujer, botonAccesorios};
        for (Button btn : botones) {
            if (btn == botonSeleccionado) {
                btn.setStyle("-fx-border-color: transparent transparent #EB7763 transparent;" + "-fx-border-width: 0 0 4 0;"
                        + "-fx-background-color: transparent;" + "-fx-padding: 5 10 5 10;" + "-fx-text-fill: #EB7763;");
            } else {
                btn.setStyle("-fx-background-color: transparent");
            }
        }
    }

    @FXML
    public void abrirMenuDesplegable(ActionEvent event) {
        abrirMenu();
    }
    @FXML
    public void ocultarMenu(ActionEvent event) {
        abrirMenu();
    }

    public void abrirMenu() {
        double destinoX = menuAbierto ? -270 : 0;

        // Animación del menú
        TranslateTransition animMenu = new TranslateTransition(Duration.millis(300), menuDesplegable);
        animMenu.setToX(destinoX);
        animMenu.setInterpolator(Interpolator.EASE_BOTH);

        // Animación del fondo oscuro
        FadeTransition animFondo = new FadeTransition(Duration.millis(300), fondoOscuro);
        if (menuAbierto) {
            animFondo.setToValue(0);
            animFondo.setOnFinished(e -> fondoOscuro.setVisible(false));;
        } else {
            fondoOscuro.setVisible(true);
            animFondo.setToValue(0.6);
        }

        animMenu.play();
        animFondo.play();

        menuAbierto = !menuAbierto;
    }

    @FXML
    public void salirCatalogo(ActionEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fieldBuscar.setOnKeyReleased(e -> {
            try {
                buscarProductos(productoAdmin.cargarProductos(), fieldBuscar.getText());
            } catch (IOException ex) {
                Logger.getLogger(MenuControlador.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        scrollCatalogo.vvalueProperty().addListener((obs, oldVal, newVal) -> {
            Button botonVisible = getBotonCategoriaVisiblePreciso();
            if (botonVisible != null) {
                aplicarSeleccion(botonVisible);
            }
        });
    }

    private Button getBotonCategoriaVisiblePreciso() {
        double viewportTop = scrollCatalogo.getVvalue() * (scrollCatalogo.getContent().getBoundsInLocal().getHeight() - scrollCatalogo.getViewportBounds().getHeight());
        double viewportCenter = viewportTop + scrollCatalogo.getViewportBounds().getHeight() / 2;

        String categoriaVisible = null;
        double minDistance = Double.MAX_VALUE;

        for (Map.Entry<String, Label> entry : mapaCategorias.entrySet()) {
            Label label = entry.getValue();
            double labelCenter = label.getBoundsInParent().getMinY() + label.getHeight() / 2;
            double distance = Math.abs(labelCenter - viewportCenter);

            if (distance < minDistance) {
                minDistance = distance;
                categoriaVisible = entry.getKey();
            }
        }

        if (categoriaVisible != null) {
            switch (categoriaVisible.toLowerCase()) {
                case "hombre":
                    return botonHombre;
                case "mujer":
                    return botonMujer;
                case "accesorios":
                    return botonAccesorios;
            }
        }

        return null;
    }

    private void cargarUsuario() {
        labelUsuario.setText(usuario.getUserName());
    }

    private void mostrarProductosDeseados() {

        contenedorDeseados.getChildren().clear();
        FlowPane contenedorTarjetas = new FlowPane();

        contenedorTarjetas.setHgap(15);
        contenedorTarjetas.setVgap(15);
        contenedorTarjetas.setPrefWrapLength(900);
        contenedorTarjetas.setPadding(new Insets(50, 0, 0, 50));

        NodoProducto nodo = usuario.getListaDeseados().getCabeza();

        // Mostrar o ocultar mensaje
        sinDeseados.setVisible(nodo == null);

        // Recorrer lista enlazada
        for (; nodo != null; nodo = nodo.siguiente) {
            AnchorPane tarjeta = crearTarjetaProducto(nodo.producto);
            if (tarjeta != null) {
                contenedorTarjetas.getChildren().add(tarjeta);
            }
        }

        contenedorDeseados.getChildren().add(contenedorTarjetas);
    }

    private void mostrarProductosHistorial() {

        contenedorHistorial.getChildren().clear();

        FlowPane contenedorTarjetas = new FlowPane();
        contenedorTarjetas.setHgap(15);
        contenedorTarjetas.setVgap(15);
        contenedorTarjetas.setPrefWrapLength(900);
        contenedorTarjetas.setPadding(new Insets(50, 0, 0, 50));

        NodoProducto nodo = usuario.getListaHistorial().getCabeza();

        // Mostrar o ocultar mensaje
        sinHistorial.setVisible(nodo == null);

        // Recorrer lista enlazada
        for (; nodo != null; nodo = nodo.siguiente) {
            AnchorPane tarjeta = crearTarjetaProductoHistorial(nodo.producto);
            if (tarjeta != null) {
                contenedorTarjetas.getChildren().add(tarjeta);
            }
        }

        contenedorHistorial.getChildren().add(contenedorTarjetas);
    }

    private void mostrarProductosCarrito() {
        contenedorCarrito.getChildren().clear();
        contenedorCarrito.setPadding(new Insets(20, 0, 0, 20));

        NodoProducto nodo = usuario.getListaCarrito().getCabeza();

        sinCarrito.setVisible(nodo == null);

        for (; nodo != null; nodo = nodo.siguiente) {
            AnchorPane tarjetaCarrito = crearTarjetaProductoCarrito(nodo.producto);
            if (tarjetaCarrito != null) {
                contenedorCarrito.getChildren().add(tarjetaCarrito);
            }
        }
    }

    private void mostrarProductosPorCategoria() throws IOException {
        ListaProducto lista = productoAdmin.cargarProductos();
        String titulo = "";

        if (lista == null || lista.getCabeza() == null) {
            return;
        }

        contenedorCatalogo.getChildren().clear();

        NodoProducto actual = lista.getCabeza();

        while (actual != null) {

            String categoria = actual.producto.getCategoria();
            if (categoria == null) {
                categoria = "Sin categoría";
            }

            boolean yaMostrada = false;
            NodoProducto busc = lista.getCabeza();

            while (busc != actual) {
                if (busc.producto != null
                        && busc.producto.getCategoria() != null
                        && busc.producto.getCategoria().equalsIgnoreCase(categoria)) {

                    yaMostrada = true;
                    break;
                }
                busc = busc.siguiente;
            }

            if (yaMostrada) {
                actual = actual.siguiente;
                continue;
            }

            titulo = categoria.substring(0, 1).toUpperCase() + categoria.substring(1);

            Label tituloCategoria = new Label(titulo);
            tituloCategoria.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
            tituloCategoria.setPadding(new Insets(50, 0, 50, 0));

            mapaCategorias.put(categoria, tituloCategoria);

            FlowPane contenedorTarjetas = new FlowPane();
            contenedorTarjetas.setHgap(15);
            contenedorTarjetas.setVgap(15);
            contenedorTarjetas.setPrefWrapLength(900);

            NodoProducto aux = lista.getCabeza();
            while (aux != null) {

                String catAux = aux.producto.getCategoria();
                if (catAux == null) {
                    catAux = "Sin categoría";
                }

                if (categoria.equalsIgnoreCase(catAux)) {

                    AnchorPane tarjeta = crearTarjetaProducto(aux.producto);
                    if (tarjeta != null) {
                        contenedorTarjetas.getChildren().add(tarjeta);
                    }
                }

                aux = aux.siguiente;
            }

            contenedorCatalogo.getChildren().addAll(tituloCategoria, contenedorTarjetas);

            actual = actual.siguiente;
        }
        scrollCatalogo.layout();
    }

    public void buscarProductos(ListaProducto lista, String filtro) throws IOException {
        filtro = filtro.toLowerCase().trim();

        if (filtro.isEmpty()) {
            mostrarProductosPorCategoria();
            return;
        }

        // 1. Limpiar el VBox donde van los resultados
        contenedorCatalogo.getChildren().clear();

        // 2. Crear UN solo FlowPane para las tarjetas encontradas
        FlowPane contenedorTarjetas = new FlowPane();
        contenedorTarjetas.setHgap(15);
        contenedorTarjetas.setVgap(15);
        contenedorTarjetas.setPrefWrapLength(900);
        contenedorTarjetas.setPadding(new Insets(50, 0, 0, 0));

        // 3. Recorrer la lista enlazada
        NodoProducto actual = lista.getCabeza();

        while (actual != null) {
            Producto p = actual.producto;

            String nombre = p.getNombre().toLowerCase();
            String categoria = p.getCategoria().toLowerCase();

            // 4. Si coincide agrega tarjeta
            if (nombre.contains(filtro)
                    || categoria.contains(filtro)) {

                Node tarjeta = crearTarjetaProducto(p);
                contenedorTarjetas.getChildren().add(tarjeta);
                animarAparicion(tarjeta);
            }

            actual = actual.siguiente;
        }

        // 5. Agregar solo un contenedor con todas las tarjetas
        contenedorCatalogo.getChildren().add(contenedorTarjetas);
    }

    private AnchorPane crearTarjetaProducto(Producto producto) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/tarjeta_producto.fxml"));
            AnchorPane tarjeta = loader.load();

            TarjetaProductoControlador controller = loader.getController();
            controller.setUsuarioAdmin(usuarioAdmin);
            controller.setListaUsuarios(listaUsuario);
            controller.setUsuario(usuario);
            controller.setProducto(producto);

            tarjeta.setPrefWidth(160);   // igual que en tu código actual
            tarjeta.setPrefHeight(240);

            return tarjeta;

        } catch (IOException e) {
            return null;
        }
    }

    private AnchorPane crearTarjetaProductoHistorial(Producto producto) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/tarjeta_producto.fxml"));
            AnchorPane tarjeta = loader.load();

            TarjetaProductoControlador controller = loader.getController();
            controller.setUsuarioAdmin(usuarioAdmin);
            controller.setListaUsuarios(listaUsuario);
            controller.setUsuario(usuario);
            controller.setProducto(producto);
            controller.ocultarBotonesTarjeta();

            tarjeta.setPrefWidth(160);
            tarjeta.setPrefHeight(240);

            return tarjeta;

        } catch (IOException e) {
            return null;
        }
    }

    private AnchorPane crearTarjetaProductoCarrito(Producto producto) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/tarjeta_carrito.fxml"));
            AnchorPane tarjeta = loader.load();

            TarjetaCarritoControlador controller = loader.getController();
            controller.setUsuarioAdmin(usuarioAdmin);
            controller.setListaUsuarios(listaUsuario);
            controller.setUsuario(usuario);
            controller.setProducto(producto);

            // IMPORTANTE: registrar esta tarjeta
            tarjetas.add(controller);
            controller.setOnCantidadCambiada(() -> {
                actualizarTotal();
            });

            return tarjeta;

        } catch (IOException e) {
            return null;
        }
    }

    private void actualizarTotal() {
        double total = calcularTotal();

        if (total <= 0) {
            labelSubTotal.setText("Subtotal");
            labelEnvio.setText("Envío");
            labelTotal.setText("Total");
        } else {
            labelSubTotal.setText("Subtotal     " + total);
            labelEnvio.setText("Envío          " + costoEnvio);
            labelTotal.setText("Total           " + (total + costoEnvio));
        }
    }

    private double calcularTotal() {
        double total = 0;

        for (TarjetaCarritoControlador t : tarjetas) {
            total += t.getCantidad() * t.getProducto().getPrecio();
        }

        return total;
    }

    private void animarAparicion(Node node) {
        // Fade de 0 → 1
        FadeTransition fade = new FadeTransition(Duration.millis(300), node);
        fade.setFromValue(0);
        fade.setToValue(1);

        // Desplazamiento suave desde 15 px abajo
        TranslateTransition move = new TranslateTransition(Duration.millis(300), node);
        move.setFromY(15);
        move.setToY(0);

        ParallelTransition animacion = new ParallelTransition(fade, move);
        animacion.play();
    }
}
